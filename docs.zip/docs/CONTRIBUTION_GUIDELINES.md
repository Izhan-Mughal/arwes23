# Contribution guidelines

## Pages

Pages should be heavy, at least initially, try not to extract anything prematurely.

## Components

Components should be generic and reusable.

## Features

Features should be unique and specific.