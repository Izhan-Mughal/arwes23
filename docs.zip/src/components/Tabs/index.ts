export { default } from './Tabs'
