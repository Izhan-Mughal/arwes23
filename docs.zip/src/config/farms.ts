import { AddressMap, ChainId } from '@sushiswap/core-sdk'

export const OLD_FARMS: AddressMap = {
  [ChainId.CELO]: '0x0769fd68dFb93167989C6f7254cd0D766Fb2841F',
}
